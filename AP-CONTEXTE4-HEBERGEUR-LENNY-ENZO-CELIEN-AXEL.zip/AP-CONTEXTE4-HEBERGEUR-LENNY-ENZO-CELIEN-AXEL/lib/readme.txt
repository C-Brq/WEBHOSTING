#SERVER
#Pour assurer le bon fonctionnement de l'architecture il est impératif d'installer les packages suivant:
sudo apt install mariadb-server
sudo apt install nginx
sudo apt install vsftpd
